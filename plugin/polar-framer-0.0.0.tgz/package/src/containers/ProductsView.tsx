import { useProducts } from "../hooks/products";
import { Product } from "@polar-sh/sdk/models/components/product";
import { AddOutlined, TextureOutlined } from "@mui/icons-material";
import { Link } from "react-router";
import { useContext } from "react";
import { OrganizationContext } from "../providers";
import { ProductPrices } from "@/components/ProductPrices";
import { Button } from "@/components/ui/button";
import { baseUrl } from "@/utils";

export const ProductsView = () => {
  const { organization } = useContext(OrganizationContext);
  const { data: products } = useProducts({
    limit: 100,
    organizationId: organization?.id,
    isArchived: false,
  });

  return (
    <>
      <div className="border-b dark:border-neutral-900 border-neutral-100 flex flex-row items-center p-4 gap-x-4 justify-between">
        <h3 className="text-sm font-medium">Products</h3>
        <a
          href={`${baseUrl}/dashboard/${organization?.slug}/products/new`}
          target="_blank"
        >
          <button className="bg-blue-500 text-white hover:bg-blue-400 dark:hover:bg-blue-600 w-6 h-6 flex flex-col items-center justify-center rounded-full">
            <AddOutlined fontSize="inherit" />
          </button>
        </a>
      </div>
      {products ? (
        products.result.items.length > 0 ? (
          <div className="flex flex-grow min-h-0 flex-col gap-4 p-4 overflow-y-auto">
            <div className="flex flex-col gap-2">
              {products.result.items.map((product) => (
                <ProductRow key={product.id} product={product} />
              ))}
            </div>
          </div>
        ) : (
          <div className="items-center flex-grow p-4 justify-center gap-y-6 flex flex-col">
            <div className="flex flex-col items-center gap-y-4">
              <div className="flex flex-col items-center gap-y-1">
                <h3 className="font-medium text-sm">No products found</h3>
                <p className="text-neutral-500 text-xs">
                  Start selling digital products today
                </p>
              </div>
              <a
                href={`${baseUrl}/dashboard/${organization?.slug}/products/new`}
                target="_blank"
              >
                <Button className="rounded-full" size="sm" variant="secondary">
                  Create Product
                </Button>
              </a>
            </div>
          </div>
        )
      ) : (
        <LoadingView />
      )}
    </>
  );
};

const Skeleton = () => {
  return (
    <div className="dark:bg-neutral-900 rounded-xl h-16 w-full animate-pulse" />
  );
};

const LoadingView = () => {
  return (
    <div className="flex flex-col gap-2 p-4 pt-0">
      <Skeleton />
      <Skeleton />
      <Skeleton />
      <Skeleton />
      <Skeleton />
    </div>
  );
};

const ProductRow = ({ product }: { product: Product }) => {
  return (
    <Link
      to={`/products/${product.id}`}
      className="flex flex-row gap-2 dark:bg-neutral-900 bg-neutral-100 hover:bg-neutral-50 hover:dark:bg-neutral-800 p-2 rounded-xl transition-colors duration-75 cursor-pointer"
    >
      <div className="flex w-full flex-row items-center gap-x-4">
        {product.medias[0] ? (
          <img
            src={product.medias[0].publicUrl}
            alt={`${product.name} media`}
            className="w-12 h-12 object-cover rounded-md"
          />
        ) : (
          <div className="w-12 h-12 flex flex-col items-center justify-center rounded-md dark:bg-neutral-800 bg-neutral-200">
            <TextureOutlined className="dark:text-neutral-700 text-neutral-400" />
          </div>
        )}
        <div className="flex flex-col gap-y-1">
          <h3 className="text-sm font-medium truncate line-clamp-1">
            {product.name}
          </h3>
          <div className="flex text-xs text-neutral-500 flex-row items-center gap-x-2">
            <ProductPrices prices={product.prices} />
          </div>
        </div>
      </div>
    </Link>
  );
};
